module.exports = {
    arrowParens: 'always',
    bracketSpacing: false,
    printWidth: 120,
    singleQuote: true,
    tabWidth: 4
};
